﻿# Local Desk v1.0.3 - Standalone Windows 10/11 x64 Desktop Application Host
$ErrorActionPreference = "SilentlyContinue"
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$IndexFile = Join-Path $AppDir "dist\index.html"
$ProfileDir = Join-Path $env:APPDATA "Local Desk\WindowProfile"
$TempDir = Join-Path $env:LOCALAPPDATA "Local Desk\Temp"

New-Item -ItemType Directory -Force -Path $ProfileDir | Out-Null
New-Item -ItemType Directory -Force -Path $TempDir | Out-Null

# 1. If a dedicated Electron runtime binary is present, launch Electron Main Process
$BundledElectron = Join-Path $AppDir "runtime\electron.exe"
if (Test-Path -LiteralPath $BundledElectron) {
  Start-Process -FilePath $BundledElectron -ArgumentList "`"$AppDir\electron\main.cjs`"" -WorkingDirectory $AppDir
  exit 0
}

# 2. Launch Chromeless Windows WebView2 / Edge Application Host Window (100% Offline, Zero Server Required)
$EdgeCandidates = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe"
)
$RegEdge = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction SilentlyContinue).'(default)'
if ($RegEdge) { $EdgeCandidates = @($RegEdge) + $EdgeCandidates }

$IndexUri = ([System.Uri]$IndexFile).AbsoluteUri
foreach ($EdgePath in $EdgeCandidates) {
  if ($EdgePath -and (Test-Path -LiteralPath $EdgePath)) {
    $EdgeArgs = "--app=`"$IndexUri`" --user-data-dir=`"$ProfileDir`" --window-size=1440,920 --allow-file-access-from-files --disable-background-networking --disable-sync --disable-translate --no-first-run --no-default-browser-check"
    Start-Process -FilePath $EdgePath -ArgumentList $EdgeArgs -WorkingDirectory $AppDir
    exit 0
  }
}

# 3. Fallback to Chrome App Window or system default HTML handler
$ChromeCandidates = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
foreach ($ChromePath in $ChromeCandidates) {
  if ($ChromePath -and (Test-Path -LiteralPath $ChromePath)) {
    $ChromeArgs = "--app=`"$IndexUri`" --user-data-dir=`"$ProfileDir`" --window-size=1440,920 --allow-file-access-from-files --disable-background-networking --no-first-run"
    Start-Process -FilePath $ChromePath -ArgumentList $ChromeArgs -WorkingDirectory $AppDir
    exit 0
  }
}

Start-Process -FilePath $IndexFile
