﻿# Local Desk v1.0.3 - Windows 10/11 x64 Installer & Shell Registration
$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\LocalDesk"
$AppDataDir = Join-Path $env:APPDATA "Local Desk"
$TempDir    = Join-Path $env:LOCALAPPDATA "Local Desk\Temp"
$ExePath    = Join-Path $InstallDir "Local Desk.exe"
$UninstPath = Join-Path $InstallDir "Uninstall Local Desk.exe"
$IcoPath    = Join-Path $InstallDir "build\local-desk-icon-v103.ico"
if (-not (Test-Path -LiteralPath $IcoPath)) {
  $IcoPath  = Join-Path $InstallDir "build\icon.ico"
}

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path $AppDataDir | Out-Null
New-Item -ItemType Directory -Force -Path $TempDir | Out-Null

# Resolve real Windows Known Folders (supports OneDrive Desktop redirection on Windows 10/11)
$WshShell = New-Object -ComObject WScript.Shell
$DesktopDir = [Environment]::GetFolderPath('Desktop')
if ($DesktopDir -and (Test-Path -LiteralPath $DesktopDir)) {
  $DesktopLnk = Join-Path $DesktopDir "Local Desk.lnk"
  if (Test-Path -LiteralPath $DesktopLnk) {
    Remove-Item -LiteralPath $DesktopLnk -Force -ErrorAction SilentlyContinue
  }
  $DesktopShortcut = $WshShell.CreateShortcut($DesktopLnk)
  $DesktopShortcut.TargetPath = $ExePath
  $DesktopShortcut.WorkingDirectory = $InstallDir
  $DesktopShortcut.IconLocation = "$IcoPath,0"
  $DesktopShortcut.Description = 'Local Desk - All-in-One Privacy-First PDF & Document Studio'
  $DesktopShortcut.Save()
}

$ProgramsDir = [Environment]::GetFolderPath('Programs')
if ($ProgramsDir) {
  $StartMenuDir = Join-Path $ProgramsDir "Local Desk"
  New-Item -ItemType Directory -Force -Path $StartMenuDir | Out-Null
  $StartLnk = Join-Path $StartMenuDir "Local Desk.lnk"
  if (Test-Path -LiteralPath $StartLnk) {
    Remove-Item -LiteralPath $StartLnk -Force -ErrorAction SilentlyContinue
  }
  $StartShortcut = $WshShell.CreateShortcut($StartLnk)
  $StartShortcut.TargetPath = $ExePath
  $StartShortcut.WorkingDirectory = $InstallDir
  $StartShortcut.IconLocation = "$IcoPath,0"
  $StartShortcut.Description = 'Local Desk - All-in-One Privacy-First PDF & Document Studio'
  $StartShortcut.Save()

  $UninstallShortcut = $WshShell.CreateShortcut((Join-Path $StartMenuDir "Uninstall Local Desk.lnk"))
  $UninstallShortcut.TargetPath = $UninstPath
  $UninstallShortcut.WorkingDirectory = $InstallDir
  $UninstallShortcut.IconLocation = "$IcoPath,0"
  $UninstallShortcut.Description = 'Uninstall Local Desk'
  $UninstallShortcut.Save()
}

# Register .pdf Open-With File Association in HKCU (No Admin Elevation Required)
$ClassesKey = "HKCU:\Software\Classes\LocalDesk.PDF"
New-Item -Path "$ClassesKey\DefaultIcon" -Force | Out-Null
Set-ItemProperty -Path "$ClassesKey" -Name "(Default)" -Value "Local Desk - All-in-One PDF & Document Studio"
Set-ItemProperty -Path "$ClassesKey\DefaultIcon" -Name "(Default)" -Value "`"$IcoPath`",0"
New-Item -Path "$ClassesKey\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$ClassesKey\shell\open\command" -Name "(Default)" -Value "`"$ExePath`" `"%1`""

# Register in Windows Settings -> Installed Apps (HKCU Uninstall Registry Key)
$UninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LocalDesk"
New-Item -Path $UninstallKey -Force | Out-Null
Set-ItemProperty -Path $UninstallKey -Name "DisplayName" -Value "Local Desk - All-in-One PDF & Document Studio"
Set-ItemProperty -Path $UninstallKey -Name "DisplayVersion" -Value "1.0.3"
Set-ItemProperty -Path $UninstallKey -Name "Publisher" -Value "Local Desk"
Set-ItemProperty -Path $UninstallKey -Name "DisplayIcon" -Value "`"$IcoPath`",0"
Set-ItemProperty -Path $UninstallKey -Name "InstallLocation" -Value $InstallDir
Set-ItemProperty -Path $UninstallKey -Name "UninstallString" -Value "`"$UninstPath`""
Set-ItemProperty -Path $UninstallKey -Name "NoModify" -Type DWord -Value 1
Set-ItemProperty -Path $UninstallKey -Name "NoRepair" -Type DWord -Value 1

# Notify Windows Shell (SHCNE_ASSOCCHANGED) & Refresh Taskbar Icon Cache Immediately
$ShellNotifyCode = @"
using System;
using System.Runtime.InteropServices;
public static class LocalDeskShellNotify {
  [DllImport("shell32.dll")]
  public static extern void SHChangeNotify(int wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);
}
"@
Add-Type -TypeDefinition $ShellNotifyCode -ErrorAction SilentlyContinue
try { [LocalDeskShellNotify]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero) } catch {}
Start-Process -FilePath "ie4uinit.exe" -ArgumentList "-ClearIconCache" -WindowStyle Hidden -ErrorAction SilentlyContinue
Start-Process -FilePath "ie4uinit.exe" -ArgumentList "-show" -WindowStyle Hidden -ErrorAction SilentlyContinue

# Launch Local Desk.exe immediately after installation completes
Start-Process -FilePath $ExePath -WorkingDirectory $InstallDir
