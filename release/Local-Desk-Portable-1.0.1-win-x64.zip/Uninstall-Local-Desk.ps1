# Local Desk v1.0.1 — Clean Windows Uninstaller
$ErrorActionPreference = "SilentlyContinue"
$DesktopDir = [Environment]::GetFolderPath('Desktop')
if ($DesktopDir) {
  Remove-Item -LiteralPath (Join-Path $DesktopDir "Local Desk.lnk") -Force
}
$ProgramsDir = [Environment]::GetFolderPath('Programs')
if ($ProgramsDir) {
  Remove-Item -LiteralPath (Join-Path $ProgramsDir "Local Desk") -Recurse -Force
}
Remove-Item -Path "HKCU:\Software\Classes\LocalDesk.PDF" -Recurse -Force
Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LocalDesk" -Recurse -Force
Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA "Local Desk\Temp") -Recurse -Force
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show("Local Desk shortcuts, file associations, and temporary caches have been removed.", "Uninstall Local Desk", "OK", "Information") | Out-Null
