# Local Desk v1.0.1 — Windows 10/11 x64 Installer & Shell Registration
$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\LocalDesk"
$AppDataDir = Join-Path $env:APPDATA "Local Desk"
$TempDir    = Join-Path $env:LOCALAPPDATA "Local Desk\Temp"
$ExePath    = Join-Path $InstallDir "Local Desk.exe"
$UninstPath = Join-Path $InstallDir "Uninstall Local Desk.exe"
$IcoPath    = Join-Path $InstallDir "build\icon.ico"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path $AppDataDir | Out-Null
New-Item -ItemType Directory -Force -Path $TempDir | Out-Null

# Resolve real Windows Known Folders (supports OneDrive Desktop redirection on Windows 10/11)
$WshShell = New-Object -ComObject WScript.Shell
$DesktopDir = [Environment]::GetFolderPath('Desktop')
if ($DesktopDir -and (Test-Path -LiteralPath $DesktopDir)) {
  $DesktopShortcut = $WshShell.CreateShortcut((Join-Path $DesktopDir "Local Desk.lnk"))
  $DesktopShortcut.TargetPath = $ExePath
  $DesktopShortcut.WorkingDirectory = $InstallDir
  $DesktopShortcut.IconLocation = "$ExePath,0"
  $DesktopShortcut.Description = "Local Desk — All-in-One Privacy-First PDF & Document Studio"
  $DesktopShortcut.Save()
}

$ProgramsDir = [Environment]::GetFolderPath('Programs')
if ($ProgramsDir) {
  $StartMenuDir = Join-Path $ProgramsDir "Local Desk"
  New-Item -ItemType Directory -Force -Path $StartMenuDir | Out-Null
  $StartShortcut = $WshShell.CreateShortcut((Join-Path $StartMenuDir "Local Desk.lnk"))
  $StartShortcut.TargetPath = $ExePath
  $StartShortcut.WorkingDirectory = $InstallDir
  $StartShortcut.IconLocation = "$ExePath,0"
  $StartShortcut.Description = "Local Desk — All-in-One Privacy-First PDF & Document Studio"
  $StartShortcut.Save()

  $UninstallShortcut = $WshShell.CreateShortcut((Join-Path $StartMenuDir "Uninstall Local Desk.lnk"))
  $UninstallShortcut.TargetPath = $UninstPath
  $UninstallShortcut.WorkingDirectory = $InstallDir
  $UninstallShortcut.IconLocation = "$IcoPath,0"
  $UninstallShortcut.Description = "Uninstall Local Desk"
  $UninstallShortcut.Save()
}

# Register .pdf Open-With File Association in HKCU (No Admin Elevation Required)
$ClassesKey = "HKCU:\Software\Classes\LocalDesk.PDF"
New-Item -Path "$ClassesKey\DefaultIcon" -Force | Out-Null
Set-ItemProperty -Path "$ClassesKey" -Name "(Default)" -Value "PDF Document (Local Desk)"
Set-ItemProperty -Path "$ClassesKey\DefaultIcon" -Name "(Default)" -Value "`"$ExePath`",0"
New-Item -Path "$ClassesKey\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$ClassesKey\shell\open\command" -Name "(Default)" -Value "`"$ExePath`" `"%1`""

# Register in Windows Settings -> Installed Apps (HKCU Uninstall Registry Key)
$UninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LocalDesk"
New-Item -Path $UninstallKey -Force | Out-Null
Set-ItemProperty -Path $UninstallKey -Name "DisplayName" -Value "Local Desk"
Set-ItemProperty -Path $UninstallKey -Name "DisplayVersion" -Value "1.0.1"
Set-ItemProperty -Path $UninstallKey -Name "Publisher" -Value "Local Desk Document Systems"
Set-ItemProperty -Path $UninstallKey -Name "DisplayIcon" -Value "`"$ExePath`",0"
Set-ItemProperty -Path $UninstallKey -Name "InstallLocation" -Value $InstallDir
Set-ItemProperty -Path $UninstallKey -Name "UninstallString" -Value "`"$UninstPath`""
Set-ItemProperty -Path $UninstallKey -Name "NoModify" -Type DWord -Value 1
Set-ItemProperty -Path $UninstallKey -Name "NoRepair" -Type DWord -Value 1

# Launch Local Desk.exe immediately after installation completes
Start-Process -FilePath $ExePath -WorkingDirectory $InstallDir
