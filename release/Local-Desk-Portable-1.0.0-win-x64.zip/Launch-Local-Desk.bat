@echo off
setlocal
title Local Desk — PDF & Document Studio (v1.0.0)
cd /d "%~dp0"

REM 1. If Electron runtime binary is present in ./runtime/Local Desk.exe or npx electron is installed, launch Electron Main Process
if exist "%~dp0Local Desk.exe" (
  start "" "%~dp0Local Desk.exe" %*
  exit /b 0
)

where electron >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  start "" electron "%~dp0electron\main.cjs" %*
  exit /b 0
)

REM 2. Standalone Windows WebView2 / Edge App-Window Host (Zero Node.js or Server Required)
set "APP_INDEX=%~dp0dist\index.html"
set "USER_DATA_DIR=%APPDATA%\Local Desk\EdgeHostProfile"
if not exist "%USER_DATA_DIR%" mkdir "%USER_DATA_DIR%"

for %%P in (
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
  "%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
) do (
  if exist %%P (
    start "" %%P --app="file:///%APP_INDEX:\=/%" --user-data-dir="%USER_DATA_DIR%" --window-size=1440,920 --allow-file-access-from-files --disable-background-networking --disable-sync --disable-translate
    exit /b 0
  )
)

start "" "%APP_INDEX%"
exit /b 0
