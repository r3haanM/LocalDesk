# Local Desk v1.0.0 — Windows 10/11 User-Space Installer & Shortcut Creator
$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\LocalDesk"
$AppDataDir = Join-Path $env:APPDATA "Local Desk"
$TempDir    = Join-Path $env:LOCALAPPDATA "Local Desk\Temp"

Write-Host "Installing Local Desk v1.0.0 to $InstallDir ..." -ForegroundColor Green
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path $AppDataDir | Out-Null
New-Item -ItemType Directory -Force -Path $TempDir | Out-Null

Copy-Item -Path "$PSScriptRoot\*" -Destination $InstallDir -Recurse -Force

# Create Desktop and Start Menu Shortcuts
$WshShell = New-Object -ComObject WScript.Shell
$DesktopShortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\Local Desk.lnk")
$DesktopShortcut.TargetPath = Join-Path $InstallDir "Launch-Local-Desk.bat"
$DesktopShortcut.WorkingDirectory = $InstallDir
$DesktopShortcut.IconLocation = Join-Path $InstallDir "build\icon.ico"
$DesktopShortcut.Description = "Local Desk — All-in-One Privacy-First PDF & Document Studio"
$DesktopShortcut.Save()

$StartMenuDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Local Desk"
New-Item -ItemType Directory -Force -Path $StartMenuDir | Out-Null
$StartShortcut = $WshShell.CreateShortcut("$StartMenuDir\Local Desk.lnk")
$StartShortcut.TargetPath = Join-Path $InstallDir "Launch-Local-Desk.bat"
$StartShortcut.WorkingDirectory = $InstallDir
$StartShortcut.IconLocation = Join-Path $InstallDir "build\icon.ico"
$StartShortcut.Description = "Local Desk — All-in-One Privacy-First PDF & Document Studio"
$StartShortcut.Save()

# Register .pdf Open-With File Association in HKCU (No Admin Elevation Required)
$ClassesKey = "HKCU:\Software\Classes\LocalDesk.PDF"
New-Item -Path "$ClassesKey\DefaultIcon" -Force | Out-Null
Set-ItemProperty -Path "$ClassesKey" -Name "(Default)" -Value "PDF Document (Local Desk)"
Set-ItemProperty -Path "$ClassesKey\DefaultIcon" -Name "(Default)" -Value "$InstallDir\build\icon.ico,0"
New-Item -Path "$ClassesKey\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$ClassesKey\shell\open\command" -Name "(Default)" -Value "`"$InstallDir\Launch-Local-Desk.bat`" `"%1`""

Write-Host "Local Desk v1.0.0 installed successfully! Launching application..." -ForegroundColor Green
Start-Process -FilePath (Join-Path $InstallDir "Launch-Local-Desk.bat")
