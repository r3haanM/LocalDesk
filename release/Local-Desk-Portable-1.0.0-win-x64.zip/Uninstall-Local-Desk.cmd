@echo off
title Uninstall Local Desk v1.0.0
echo Removing Local Desk Desktop & Start Menu shortcuts...
del /f /q "%USERPROFILE%\Desktop\Local Desk.lnk" 2>nul
rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Local Desk" 2>nul
reg delete "HKCU\Software\Classes\LocalDesk.PDF" /f 2>nul
echo Cleaning temporary workspace cache...
rmdir /s /q "%LOCALAPPDATA%\Local Desk\Temp" 2>nul
echo Local Desk has been uninstalled. User preferences in "%APPDATA%\Local Desk" were preserved.
